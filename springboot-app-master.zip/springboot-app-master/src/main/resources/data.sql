insert into survey_details(first_name,last_name,email,telephone_number,street_address,city,state,zip,date_of_survey,most_liked,interested_in,recommending,additional_comments)
values('Test1','Test2','test@gmail.com','1234567890','abc','efg','hij','123456','2022-04-28','Student,Campus','Internet','Likely','Done');


insert into survey_details(first_name,last_name,email,telephone_number,street_address,city,state,zip,date_of_survey,most_liked,interested_in,recommending,additional_comments)
values('Test3','Test4','test@gmail.com','1234567890','abc','efg','hij','123456','2022-04-28','Student,Campus','Internet','Likely','Done');
